# Lecteur Pro — lecteur vidéo Android (Kotlin + libVLC)

Cible : OPPO F7 (CPH1821EX), Android 10 (API 29), arm64-v8a.

## Compiler l'APK debug

    gradle assembleDebug

Prérequis : JDK 17, Gradle 8.5 ou plus récent, Android SDK (platform 34 + build-tools).
Il n'y a pas de gradlew dans ce projet : utiliser `gradle` directement, ou générer le wrapper avec `gradle wrapper --gradle-version 8.5`.

APK produit : `app/build/outputs/apk/debug/app-debug.apk`

## Points importants

- Un seul moteur de lecture : libVLC (`org.videolan.android:libvlc-all`). Aucun ExoPlayer / Media3.
- minifyEnabled = false partout (debug et release).
- En cas de plantage, l'app écrit `Téléchargements/erreur.txt` et affiche le rapport à l'écran (CrashActivity).
- Si `libvlc-all:3.5.1` est introuvable, prendre la dernière version stable sur Maven Central.
- Le code n'a pas pu être compilé par son auteur : corriger toute erreur de compilation éventuelle sans changer le design ni la logique.

## Vérifications avant livraison

1. `unzip -l app-debug.apk` : présence de `classes.dex`, `lib/arm64-v8a/libvlc.so`, `lib/arm64-v8a/libvlcjni.so`.
2. Tous les layouts n'utilisent que des classes présentes (RecyclerView, VLCVideoLayout, vues standard).
3. Lancer l'app (émulateur arm64 / API 29 si possible) et vérifier qu'aucune exception n'apparaît.
