package com.ronald.lecteurpro

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.io.File
import kotlin.math.abs
import kotlin.math.roundToInt

class PlayerActivity : AppCompatActivity() {

    // ---- moteur ----
    private var libVLC: LibVLC? = null
    private var player: MediaPlayer? = null
    private var pfd: ParcelFileDescriptor? = null
    private val ui = Handler(Looper.getMainLooper())

    // ---- vues ----
    private lateinit var videoLayout: VLCVideoLayout
    private lateinit var touchLayer: View
    private lateinit var controls: View
    private lateinit var hud: TextView
    private lateinit var btnUnlock: ImageButton
    private lateinit var btnPlay: ImageButton
    private lateinit var btnPrev: ImageButton
    private lateinit var btnNext: ImageButton
    private lateinit var tvTitle: TextView
    private lateinit var tvTime: TextView
    private lateinit var tvDuration: TextView
    private lateinit var seek: SeekBar
    private lateinit var btnSpeed: TextView
    private lateinit var btnRatio: TextView

    // ---- état ----
    private var items: List<Video> = emptyList()
    private var index = 0
    private var hw = true
    private var started = false
    private var resumeAfterStop = false
    private var locked = false
    private var controlsVisible = true
    private var seeking = false

    private val speeds = floatArrayOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
    private var speedIndex = 2

    private val ratioNames = arrayOf("Ajusté", "Écran", "Remplir", "16:9", "4:3", "Original")
    private val ratioTypes = arrayOf(
        MediaPlayer.ScaleType.SURFACE_BEST_FIT,
        MediaPlayer.ScaleType.SURFACE_FIT_SCREEN,
        MediaPlayer.ScaleType.SURFACE_FILL,
        MediaPlayer.ScaleType.SURFACE_16_9,
        MediaPlayer.ScaleType.SURFACE_4_3,
        MediaPlayer.ScaleType.SURFACE_ORIGINAL
    )
    private var ratioIndex = 0

    // gestes
    private var gestureMode = 0 // 0 aucun, 1 avance/recul, 2 volume, 3 luminosité
    private var startTimeMs = 0L
    private var pendingSeek = 0L
    private var startVol = 0
    private var startBright = 0.5f
    private lateinit var audioManager: AudioManager

    private val posPrefs by lazy { getSharedPreferences("positions", Context.MODE_PRIVATE) }
    private val hideRunnable = Runnable { hideControls() }
    private val hideHudRunnable = Runnable { hud.visibility = View.GONE }
    private val hideUnlockRunnable = Runnable { btnUnlock.visibility = View.GONE }

    private val subtitleLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) addExternalSubtitle(uri)
        }

    // =====================================================================
    // Cycle de vie
    // =====================================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_player)
        hideSystemBars()
        bindViews()

        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        hw = getSharedPreferences("settings", Context.MODE_PRIVATE).getBoolean("hw", true)

        if (!resolvePlaylist()) {
            Toast.makeText(this, "Aucune vidéo à lire.", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        if (!initPlayer()) return
        setupControls()
        setupGestures()
    }

    override fun onStart() {
        super.onStart()
        val p = player ?: return
        p.attachViews(videoLayout, null, true, false)
        if (!started) {
            started = true
            startCurrent()
        } else if (resumeAfterStop) {
            p.play()
        }
    }

    override fun onStop() {
        super.onStop()
        val p = player ?: return
        resumeAfterStop = p.isPlaying
        savePosition()
        p.pause()
        p.detachViews()
    }

    override fun onDestroy() {
        super.onDestroy()
        ui.removeCallbacksAndMessages(null)
        try {
            player?.setEventListener(null)
            player?.stop()
            player?.release()
            libVLC?.release()
        } catch (_: Throwable) {
        }
        player = null
        libVLC = null
        closeFd()
    }

    // =====================================================================
    // Initialisation
    // =====================================================================

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun bindViews() {
        videoLayout = findViewById(R.id.videoLayout)
        touchLayer = findViewById(R.id.touchLayer)
        controls = findViewById(R.id.controls)
        hud = findViewById(R.id.hud)
        btnUnlock = findViewById(R.id.btnUnlock)
        btnPlay = findViewById(R.id.btnPlay)
        btnPrev = findViewById(R.id.btnPrev)
        btnNext = findViewById(R.id.btnNext)
        tvTitle = findViewById(R.id.tvPTitle)
        tvTime = findViewById(R.id.tvTime)
        tvDuration = findViewById(R.id.tvDuration)
        seek = findViewById(R.id.seek)
        btnSpeed = findViewById(R.id.btnSpeed)
        btnRatio = findViewById(R.id.btnRatio)
    }

    private fun resolvePlaylist(): Boolean {
        val data = intent.data ?: return false
        val idx = intent.getIntExtra("index", -1)
        val holder = PlaylistHolder.items
        if (idx in holder.indices && holder[idx].uri == data) {
            items = holder
            index = idx
        } else {
            val title = intent.getStringExtra("title") ?: displayName(data) ?: "Vidéo"
            items = listOf(Video(0L, data, title))
            index = 0
        }
        return true
    }

    private fun displayName(uri: Uri): String? {
        try {
            if (uri.scheme == "content") {
                contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                    ?.use { c ->
                        if (c.moveToFirst()) return c.getString(0)
                    }
            }
        } catch (_: Throwable) {
        }
        return uri.lastPathSegment
    }

    private fun initPlayer(): Boolean {
        return try {
            val options = arrayListOf("--no-drop-late-frames", "--no-skip-frames")
            val vlc = LibVLC(this, options)
            val p = MediaPlayer(vlc)
            p.setEventListener(MediaPlayer.EventListener { ev ->
                runOnUiThread { onPlayerEvent(ev) }
            })
            libVLC = vlc
            player = p
            true
        } catch (t: Throwable) {
            showError("Le moteur vidéo n'a pas pu démarrer.\n\n${t.javaClass.simpleName}: ${t.message}", true)
            false
        }
    }

    // =====================================================================
    // Lecture
    // =====================================================================

    private fun startCurrent() {
        val item = items.getOrNull(index) ?: return
        val vlc = libVLC ?: return
        val p = player ?: return
        tvTitle.text = item.title
        closeFd()

        val uri = item.uri
        val media: Media = try {
            val scheme = uri.scheme ?: ""
            if (scheme == "content" || scheme == "file") {
                val fd = contentResolver.openFileDescriptor(uri, "r")
                    ?: throw IllegalStateException("Fichier introuvable")
                pfd = fd
                Media(vlc, fd.fileDescriptor)
            } else {
                Media(vlc, uri)
            }
        } catch (e: Exception) {
            showError("Impossible d'ouvrir ce fichier.\n${e.message}", false)
            return
        }

        val saved = posPrefs.getLong(uri.toString(), 0L)
        media.setHWDecoderEnabled(hw, false)
        if (!hw) media.addOption(":avcodec-hw=none")
        if (saved > 5000L) media.addOption(":start-time=${saved / 1000.0}")
        p.setMedia(media)
        media.release()
        p.play()
        p.setRate(speeds[speedIndex])
        updateNavButtons()
    }

    private fun closeFd() {
        try {
            pfd?.close()
        } catch (_: Throwable) {
        }
        pfd = null
    }

    private fun onPlayerEvent(ev: MediaPlayer.Event) {
        when (ev.type) {
            MediaPlayer.Event.Playing -> {
                btnPlay.setImageResource(R.drawable.ic_pause)
                player?.setRate(speeds[speedIndex])
                updateLength()
                scheduleHide()
            }
            MediaPlayer.Event.Paused,
            MediaPlayer.Event.Stopped -> {
                btnPlay.setImageResource(R.drawable.ic_play)
                showControls()
            }
            MediaPlayer.Event.EndReached -> {
                posPrefs.edit().remove(items[index].uri.toString()).apply()
                ui.post { if (!playNext()) finish() }
            }
            MediaPlayer.Event.EncounteredError -> {
                Toast.makeText(
                    this,
                    "Impossible de lire cette vidéo (format ou fichier non pris en charge).",
                    Toast.LENGTH_LONG
                ).show()
            }
            MediaPlayer.Event.LengthChanged -> updateLength()
            MediaPlayer.Event.TimeChanged -> updateProgress()
        }
    }

    private fun updateLength() {
        val len = player?.getLength() ?: 0L
        if (len > 0L) {
            seek.max = len.toInt()
            tvDuration.text = Fmt.duration(len)
        }
    }

    private fun updateProgress() {
        val p = player ?: return
        if (seeking) return
        val t = p.getTime()
        seek.progress = t.toInt()
        tvTime.text = Fmt.duration(t)
    }

    private fun savePosition() {
        val p = player ?: return
        val item = items.getOrNull(index) ?: return
        val len = p.getLength()
        val t = p.getTime()
        if (len <= 0L || t < 0L) return
        val key = item.uri.toString()
        if (t < 5000L || t > len - 10000L) {
            posPrefs.edit().remove(key).apply()
        } else {
            posPrefs.edit().putLong(key, t).apply()
        }
    }

    private fun playIndex(i: Int) {
        if (i !in items.indices) return
        savePosition()
        index = i
        startCurrent()
    }

    private fun playNext(): Boolean {
        return if (index + 1 < items.size) {
            playIndex(index + 1)
            true
        } else false
    }

    private fun updateNavButtons() {
        btnPrev.alpha = if (index > 0) 1f else 0.35f
        btnNext.alpha = if (index + 1 < items.size) 1f else 0.35f
    }

    private fun togglePlay() {
        val p = player ?: return
        if (p.isPlaying) p.pause() else p.play()
    }

    private fun seekBy(ms: Long) {
        val p = player ?: return
        val len = p.getLength()
        val upper = if (len > 0L) len else Long.MAX_VALUE
        val t = (p.getTime() + ms).coerceIn(0L, upper)
        p.setTime(t)
        showHud(if (ms < 0) "◀◀  10 s" else "10 s  ▶▶")
    }

    // =====================================================================
    // Contrôles
    // =====================================================================

    private fun setupControls() {
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        btnPlay.setOnClickListener {
            togglePlay()
            scheduleHide()
        }
        btnPrev.setOnClickListener { playIndex(index - 1) }
        btnNext.setOnClickListener { playIndex(index + 1) }
        findViewById<View>(R.id.btnRew).setOnClickListener { seekBy(-10000L); scheduleHide() }
        findViewById<View>(R.id.btnFwd).setOnClickListener { seekBy(10000L); scheduleHide() }

        btnSpeed.setOnClickListener {
            speedIndex = (speedIndex + 1) % speeds.size
            player?.setRate(speeds[speedIndex])
            updateSpeedLabel()
            scheduleHide()
        }
        btnRatio.setOnClickListener {
            setRatio((ratioIndex + 1) % ratioTypes.size)
            scheduleHide()
        }
        findViewById<View>(R.id.btnAudio).setOnClickListener { chooseAudio() }
        findViewById<View>(R.id.btnSubs).setOnClickListener { chooseSubtitles() }

        findViewById<View>(R.id.btnLock).setOnClickListener {
            locked = true
            hideControls()
            Toast.makeText(this, "Écran verrouillé. Touchez l'écran pour afficher le cadenas.", Toast.LENGTH_SHORT).show()
        }
        btnUnlock.setOnClickListener {
            locked = false
            btnUnlock.visibility = View.GONE
            showControls()
        }

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) tvTime.text = Fmt.duration(progress.toLong())
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {
                seeking = true
                ui.removeCallbacks(hideRunnable)
            }

            override fun onStopTrackingTouch(sb: SeekBar?) {
                player?.setTime((sb?.progress ?: 0).toLong())
                seeking = false
                scheduleHide()
            }
        })
        updateSpeedLabel()
    }

    private fun updateSpeedLabel() {
        val s = speeds[speedIndex]
        btnSpeed.text = if (s == s.toInt().toFloat()) "${s.toInt()}x" else "${s}x"
    }

    private fun setRatio(i: Int) {
        ratioIndex = i
        try {
            player?.setVideoScale(ratioTypes[i])
        } catch (_: Throwable) {
        }
        btnRatio.text = ratioNames[i]
        showHud(ratioNames[i])
    }

    private fun showControls() {
        if (locked) return
        controlsVisible = true
        controls.animate().cancel()
        controls.visibility = View.VISIBLE
        controls.animate().alpha(1f).setDuration(150).start()
        scheduleHide()
    }

    private fun hideControls() {
        controlsVisible = false
        controls.animate().cancel()
        controls.animate().alpha(0f).setDuration(150).withEndAction {
            if (!controlsVisible) controls.visibility = View.GONE
        }.start()
    }

    private fun scheduleHide() {
        ui.removeCallbacks(hideRunnable)
        if (player?.isPlaying == true && !seeking && !locked) {
            ui.postDelayed(hideRunnable, 3500L)
        }
    }

    private fun showHud(text: String) {
        hud.text = text
        hud.visibility = View.VISIBLE
        ui.removeCallbacks(hideHudRunnable)
        ui.postDelayed(hideHudRunnable, 900L)
    }

    // =====================================================================
    // Gestes
    // =====================================================================

    @SuppressLint("ClickableViewAccessibility")
    private fun setupGestures() {
        val scaleDetector = ScaleGestureDetector(
            this,
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                private var factor = 1f
                override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                    factor = 1f
                    return true
                }

                override fun onScale(detector: ScaleGestureDetector): Boolean {
                    factor *= detector.scaleFactor
                    return true
                }

                override fun onScaleEnd(detector: ScaleGestureDetector) {
                    if (locked) return
                    if (factor > 1.15f) setRatio(2) // Remplir
                    else if (factor < 0.87f) setRatio(0) // Ajusté
                }
            })

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (locked) {
                    btnUnlock.visibility = View.VISIBLE
                    ui.removeCallbacks(hideUnlockRunnable)
                    ui.postDelayed(hideUnlockRunnable, 2500L)
                } else if (controlsVisible) {
                    hideControls()
                } else {
                    showControls()
                }
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (locked) return true
                val w = touchLayer.width.toFloat()
                when {
                    e.x < w / 3f -> seekBy(-10000L)
                    e.x > w * 2f / 3f -> seekBy(10000L)
                    else -> togglePlay()
                }
                return true
            }

            override fun onScroll(
                e1: MotionEvent?,
                e2: MotionEvent,
                distanceX: Float,
                distanceY: Float
            ): Boolean {
                if (locked || e1 == null || scaleDetector.isInProgress) return false
                handleScroll(e1, e2)
                return true
            }
        })

        touchLayer.setOnTouchListener { _, ev ->
            scaleDetector.onTouchEvent(ev)
            gd.onTouchEvent(ev)
            if (ev.actionMasked == MotionEvent.ACTION_UP ||
                ev.actionMasked == MotionEvent.ACTION_CANCEL
            ) {
                finishGesture()
            }
            true
        }
    }

    private fun handleScroll(e1: MotionEvent, e2: MotionEvent) {
        val dx = e2.x - e1.x
        val dy = e2.y - e1.y

        if (gestureMode == 0) {
            if (abs(dx) > abs(dy) && abs(dx) > 30f) {
                gestureMode = 1
                startTimeMs = player?.getTime() ?: 0L
            } else if (abs(dy) > 30f) {
                if (e1.x < touchLayer.width / 2f) {
                    gestureMode = 3
                    val cur = window.attributes.screenBrightness
                    startBright = if (cur < 0f) 0.5f else cur
                } else {
                    gestureMode = 2
                    startVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                }
            } else {
                return
            }
        }

        val h = touchLayer.height.coerceAtLeast(1).toFloat()
        when (gestureMode) {
            1 -> {
                val len = player?.getLength() ?: 0L
                val upper = if (len > 0L) len else Long.MAX_VALUE
                pendingSeek = (startTimeMs + (dx * 80f).toLong()).coerceIn(0L, upper)
                val diff = pendingSeek - startTimeMs
                val sign = if (diff >= 0) "+" else "−"
                showHud("${Fmt.duration(pendingSeek)}  ($sign${Fmt.duration(abs(diff))})")
            }
            2 -> {
                val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                val v = (startVol - dy / h * max * 1.3f).roundToInt().coerceIn(0, max)
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0)
                showHud("Volume  ${if (max > 0) v * 100 / max else 0}%")
            }
            3 -> {
                val b = (startBright - dy / h * 1.3f).coerceIn(0.02f, 1f)
                val lp = window.attributes
                lp.screenBrightness = b
                window.attributes = lp
                showHud("Luminosité  ${(b * 100).roundToInt()}%")
            }
        }
    }

    private fun finishGesture() {
        if (gestureMode == 1) {
            player?.setTime(pendingSeek)
        }
        gestureMode = 0
    }

    // =====================================================================
    // Pistes audio / sous-titres
    // =====================================================================

    private fun chooseAudio() {
        val p = player ?: return
        val tracks = p.getAudioTracks()
        if (tracks == null || tracks.isEmpty()) {
            Toast.makeText(this, "Aucune piste audio disponible.", Toast.LENGTH_SHORT).show()
            return
        }
        val names = tracks.map { it.name ?: "Piste ${it.id}" }.toTypedArray()
        val current = tracks.indexOfFirst { it.id == p.getAudioTrack() }.coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Piste audio")
            .setSingleChoiceItems(names, current) { d, which ->
                p.setAudioTrack(tracks[which].id)
                d.dismiss()
            }
            .show()
    }

    private fun chooseSubtitles() {
        val p = player ?: return
        val tracks = p.getSpuTracks()
        val names = ArrayList<String>()
        if (tracks != null) {
            for (t in tracks) names.add(t.name ?: "Piste ${t.id}")
        }
        names.add("＋ Ajouter un fichier de sous-titres…")
        val current = if (tracks != null) {
            tracks.indexOfFirst { it.id == p.getSpuTrack() }.coerceAtLeast(0)
        } else 0
        AlertDialog.Builder(this)
            .setTitle("Sous-titres")
            .setSingleChoiceItems(names.toTypedArray(), current) { d, which ->
                if (tracks != null && which < tracks.size) {
                    p.setSpuTrack(tracks[which].id)
                } else {
                    subtitleLauncher.launch(arrayOf("*/*"))
                }
                d.dismiss()
            }
            .show()
    }

    private fun addExternalSubtitle(uri: Uri) {
        try {
            val name = (displayName(uri) ?: "sub.srt").replace('/', '_')
            val f = File(cacheDir, "sub_$name")
            contentResolver.openInputStream(uri)?.use { input ->
                f.outputStream().use { out -> input.copyTo(out) }
            }
            // 0 = type "sous-titre" pour libVLC
            player?.addSlave(0, Uri.fromFile(f), true)
            Toast.makeText(this, "Sous-titres ajoutés.", Toast.LENGTH_SHORT).show()
        } catch (t: Throwable) {
            Toast.makeText(this, "Impossible d'ajouter ces sous-titres.", Toast.LENGTH_LONG).show()
        }
    }

    // =====================================================================
    // Erreurs
    // =====================================================================

    private fun showError(message: String, finishAfter: Boolean) {
        if (isFinishing) return
        AlertDialog.Builder(this)
            .setTitle("Lecture impossible")
            .setMessage(message)
            .setCancelable(!finishAfter)
            .setPositiveButton("OK") { _, _ -> if (finishAfter) finish() }
            .show()
    }
}
