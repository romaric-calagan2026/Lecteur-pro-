package com.ronald.lecteurpro

import android.app.Application
import android.content.ContentValues
import android.content.Intent
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import kotlin.system.exitProcess

/**
 * Au lieu de se fermer sans rien dire, l'app enregistre l'erreur dans
 * Téléchargements/erreur.txt et l'affiche à l'écran (CrashActivity).
 */
class App : Application() {

    override fun onCreate() {
        super.onCreate()
        installCrashHandler()
    }

    private fun installCrashHandler() {
        Thread.setDefaultUncaughtExceptionHandler { _, throwable ->
            try {
                val inCrashProcess = Build.VERSION.SDK_INT >= 28 &&
                    (Application.getProcessName() ?: "").endsWith(":crash")
                if (!inCrashProcess) {
                    val sw = StringWriter()
                    throwable.printStackTrace(PrintWriter(sw))
                    val report = buildString {
                        append("Rapport d'erreur Lecteur Pro\n")
                        append("Fabricant : ").append(Build.MANUFACTURER).append('\n')
                        append("Modèle : ").append(Build.MODEL).append('\n')
                        append("Android : ").append(Build.VERSION.RELEASE)
                            .append(" (API ").append(Build.VERSION.SDK_INT).append(")\n\n")
                        append(sw.toString())
                    }
                    saveReport(report)
                    val intent = Intent(this, CrashActivity::class.java)
                    intent.putExtra("report", report)
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                    startActivity(intent)
                }
            } catch (_: Throwable) {
            }
            android.os.Process.killProcess(android.os.Process.myPid())
            exitProcess(10)
        }
    }

    private fun saveReport(text: String) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, "erreur.txt")
                    put(MediaStore.MediaColumns.MIME_TYPE, "text/plain")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) }
                }
            } else {
                @Suppress("DEPRECATION")
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                dir.mkdirs()
                File(dir, "erreur.txt").writeText(text)
            }
        } catch (_: Throwable) {
        }
        try {
            File(filesDir, "last_crash.txt").writeText(text)
        } catch (_: Throwable) {
        }
    }
}
