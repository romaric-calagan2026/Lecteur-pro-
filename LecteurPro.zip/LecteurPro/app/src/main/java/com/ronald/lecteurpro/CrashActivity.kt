package com.ronald.lecteurpro

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.TypedValue
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Écran affiché à la place d'une fermeture silencieuse. Construit en code, sans layout XML. */
class CrashActivity : Activity() {

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val report = intent.getStringExtra("report") ?: "Aucun rapport disponible."

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0E0F1A"))
            setPadding(dp(20), dp(40), dp(20), dp(20))
        }

        val title = TextView(this).apply {
            text = "Lecteur Pro a rencontré une erreur"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
        }
        val desc = TextView(this).apply {
            text = "Le rapport est enregistré dans Téléchargements/erreur.txt. Copiez-le et envoyez-le pour diagnostic."
            setTextColor(Color.parseColor("#9AA0C3"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setPadding(0, dp(8), 0, dp(12))
        }
        val reportView = TextView(this).apply {
            text = report
            setTextColor(Color.parseColor("#ECEEFF"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = android.graphics.Typeface.MONOSPACE
            setTextIsSelectable(true)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setBackgroundColor(Color.parseColor("#181A2B"))
        }
        val scroll = ScrollView(this).apply {
            addView(reportView)
        }

        val btnCopy = Button(this).apply {
            text = "COPIER LE RAPPORT"
            setOnClickListener {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("rapport", report))
                Toast.makeText(this@CrashActivity, "Rapport copié", Toast.LENGTH_SHORT).show()
            }
        }
        val btnRestart = Button(this).apply {
            text = "RELANCER L'APPLICATION"
            setOnClickListener {
                val i = Intent(this@CrashActivity, MainActivity::class.java)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                startActivity(i)
                finish()
            }
        }

        root.addView(title)
        root.addView(desc)
        root.addView(
            scroll,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        root.addView(btnCopy)
        root.addView(btnRestart)
        setContentView(root)
    }
}
