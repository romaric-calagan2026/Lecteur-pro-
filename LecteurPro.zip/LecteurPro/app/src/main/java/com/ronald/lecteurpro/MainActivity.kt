package com.ronald.lecteurpro

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var adapter: VideoAdapter
    private lateinit var list: RecyclerView
    private lateinit var permPanel: View
    private lateinit var emptyView: TextView
    private lateinit var tvInfo: TextView
    private lateinit var searchRow: View
    private lateinit var searchBox: EditText
    private lateinit var btnView: ImageButton

    private var all: List<Video> = emptyList()
    private var folderFilter: String? = null
    private var sortMode = 1 // 0 nom, 1 date, 2 durée, 3 taille
    private var query = ""
    private var grid = false

    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("settings", Context.MODE_PRIVATE) }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                onPermissionOk()
            } else {
                denyCount++
                showPermPanel()
            }
        }

    private val openLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: Throwable) {
                }
                openSingle(uri, null)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        list = findViewById(R.id.list)
        permPanel = findViewById(R.id.permPanel)
        emptyView = findViewById(R.id.emptyView)
        tvInfo = findViewById(R.id.tvInfo)
        searchRow = findViewById(R.id.searchRow)
        searchBox = findViewById(R.id.searchBox)
        btnView = findViewById(R.id.btnView)

        grid = prefs.getBoolean("grid", false)
        adapter = VideoAdapter(this) { position -> playAt(position) }
        applyLayoutMode()

        findViewById<ImageButton>(R.id.btnSearch).setOnClickListener { toggleSearch() }
        findViewById<ImageButton>(R.id.btnSort).setOnClickListener { showSortMenu(it) }
        btnView.setOnClickListener {
            grid = !grid
            prefs.edit().putBoolean("grid", grid).apply()
            applyLayoutMode()
        }
        findViewById<ImageButton>(R.id.btnMore).setOnClickListener { showMoreMenu(it) }
        findViewById<ImageButton>(R.id.btnOpen).setOnClickListener {
            openLauncher.launch(arrayOf("*/*"))
        }
        findViewById<View>(R.id.btnGrant).setOnClickListener { requestPermissionOrSettings() }

        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString() ?: ""
                applyFilters()
            }
        })

        if (hasPermission()) onPermissionOk() else permLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

    override fun onResume() {
        super.onResume()
        if (hasPermission()) onPermissionOk()
    }

    private fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) ==
            PackageManager.PERMISSION_GRANTED

    private var denyCount = 0

    private fun requestPermissionOrSettings() {
        // Après deux refus, Android n'affiche plus la fenêtre : on ouvre les réglages de l'app.
        if (denyCount >= 2) {
            try {
                val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                i.data = Uri.fromParts("package", packageName, null)
                startActivity(i)
                Toast.makeText(
                    this,
                    "Autorisations > Stockage > Autoriser",
                    Toast.LENGTH_LONG
                ).show()
            } catch (_: Throwable) {
            }
        } else {
            permLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    private fun onPermissionOk() {
        permPanel.visibility = View.GONE
        loadVideos()
    }

    private fun showPermPanel() {
        permPanel.visibility = View.VISIBLE
        emptyView.visibility = View.GONE
    }

    private fun applyLayoutMode() {
        adapter.grid = grid
        list.layoutManager = if (grid) GridLayoutManager(this, 2) else LinearLayoutManager(this)
        list.adapter = adapter
        btnView.setImageResource(if (grid) R.drawable.ic_list else R.drawable.ic_grid)
    }

    private fun toggleSearch() {
        if (searchRow.visibility == View.VISIBLE) {
            searchRow.visibility = View.GONE
            searchBox.setText("")
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(searchBox.windowToken, 0)
        } else {
            searchRow.visibility = View.VISIBLE
            searchBox.requestFocus()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(searchBox, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    private fun showSortMenu(anchor: View) {
        val menu = PopupMenu(this, anchor)
        menu.menu.add(0, 0, 0, "Nom (A → Z)")
        menu.menu.add(0, 1, 1, "Plus récentes")
        menu.menu.add(0, 2, 2, "Durée")
        menu.menu.add(0, 3, 3, "Taille")
        menu.setOnMenuItemClickListener {
            sortMode = it.itemId
            applyFilters()
            true
        }
        menu.show()
    }

    private fun showMoreMenu(anchor: View) {
        val menu = PopupMenu(this, anchor)
        menu.menu.add(0, 0, 0, "Dossiers")
        menu.menu.add(0, 1, 1, "Lire un lien réseau")
        menu.menu.add(0, 2, 2, "Réglages")
        menu.setOnMenuItemClickListener {
            when (it.itemId) {
                0 -> showFolders()
                1 -> showLinkDialog()
                2 -> showSettings()
            }
            true
        }
        menu.show()
    }

    private fun showFolders() {
        val counts = LinkedHashMap<String, Int>()
        for (v in all) counts[v.folder] = (counts[v.folder] ?: 0) + 1
        val names = ArrayList<String>()
        names.add("Toutes les vidéos (${all.size})")
        val keys = counts.keys.sorted()
        for (k in keys) names.add("$k (${counts[k]})")
        AlertDialog.Builder(this)
            .setTitle("Dossiers")
            .setItems(names.toTypedArray()) { _, which ->
                folderFilter = if (which == 0) null else keys[which - 1]
                applyFilters()
            }
            .show()
    }

    private fun showLinkDialog() {
        val input = EditText(this)
        input.hint = "https://..."
        input.setSingleLine()
        AlertDialog.Builder(this)
            .setTitle("Lire un lien réseau")
            .setView(input)
            .setPositiveButton("Lire") { _, _ ->
                val url = input.text.toString().trim()
                if (url.isNotEmpty()) openSingle(Uri.parse(url), url)
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun showSettings() {
        val hw = prefs.getBoolean("hw", true)
        val checked = booleanArrayOf(hw)
        AlertDialog.Builder(this)
            .setTitle("Réglages")
            .setMultiChoiceItems(arrayOf("Décodage matériel (recommandé)"), checked) { _, i, isChecked ->
                checked[i] = isChecked
            }
            .setPositiveButton("OK") { _, _ ->
                prefs.edit().putBoolean("hw", checked[0]).apply()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun loadVideos() {
        io.execute {
            val result = ArrayList<Video>()
            try {
                val base = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                val proj = arrayOf(
                    MediaStore.Video.Media._ID,
                    MediaStore.Video.Media.DISPLAY_NAME,
                    MediaStore.Video.Media.DURATION,
                    MediaStore.Video.Media.SIZE,
                    MediaStore.Video.Media.DATE_ADDED,
                    MediaStore.Video.Media.BUCKET_DISPLAY_NAME
                )
                contentResolver.query(base, proj, null, null, null)?.use { c ->
                    val iId = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                    val iName = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                    val iDur = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                    val iSize = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                    val iDate = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
                    val iBucket = c.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
                    while (c.moveToNext()) {
                        val id = c.getLong(iId)
                        result.add(
                            Video(
                                id = id,
                                uri = ContentUris.withAppendedId(base, id),
                                title = c.getString(iName) ?: "Vidéo",
                                durationMs = c.getLong(iDur),
                                size = c.getLong(iSize),
                                dateAdded = c.getLong(iDate),
                                folder = c.getString(iBucket) ?: "Autres"
                            )
                        )
                    }
                }
            } catch (_: Exception) {
            }
            main.post {
                all = result
                applyFilters()
            }
        }
    }

    private fun applyFilters() {
        val folder = folderFilter
        val byFolder = if (folder != null) all.filter { it.folder == folder } else all
        val byQuery = if (query.isNotBlank()) {
            byFolder.filter { it.title.contains(query, ignoreCase = true) }
        } else byFolder
        val sorted = when (sortMode) {
            0 -> byQuery.sortedBy { it.title.lowercase() }
            2 -> byQuery.sortedByDescending { it.durationMs }
            3 -> byQuery.sortedByDescending { it.size }
            else -> byQuery.sortedByDescending { it.dateAdded }
        }
        adapter.items = sorted
        adapter.notifyDataSetChanged()
        tvInfo.text = "${sorted.size} vidéo(s)" + (if (folder != null) "  •  $folder" else "")
        emptyView.visibility =
            if (sorted.isEmpty() && hasPermission()) View.VISIBLE else View.GONE
    }

    private fun playAt(position: Int) {
        val v = adapter.items.getOrNull(position) ?: return
        PlaylistHolder.items = adapter.items
        val i = Intent(this, PlayerActivity::class.java)
        i.data = v.uri
        i.putExtra("title", v.title)
        i.putExtra("index", position)
        startActivity(i)
    }

    private fun openSingle(uri: Uri, title: String?) {
        PlaylistHolder.items = emptyList()
        val i = Intent(this, PlayerActivity::class.java)
        i.data = uri
        if (title != null) i.putExtra("title", title)
        i.putExtra("index", -1)
        startActivity(i)
    }
}
