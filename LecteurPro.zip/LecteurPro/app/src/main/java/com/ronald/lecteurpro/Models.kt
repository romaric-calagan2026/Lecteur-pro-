package com.ronald.lecteurpro

import android.net.Uri
import java.util.Locale

data class Video(
    val id: Long,
    val uri: Uri,
    val title: String,
    val durationMs: Long = 0L,
    val size: Long = 0L,
    val dateAdded: Long = 0L,
    val folder: String = ""
)

/** Liste de lecture partagée entre l'accueil et le lecteur. */
object PlaylistHolder {
    var items: List<Video> = emptyList()
}

object Fmt {
    fun duration(ms: Long): String {
        val total = ms.coerceAtLeast(0L) / 1000L
        val h = total / 3600L
        val m = (total % 3600L) / 60L
        val s = total % 60L
        return if (h > 0L) {
            String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        } else {
            String.format(Locale.US, "%02d:%02d", m, s)
        }
    }

    fun size(bytes: Long): String {
        if (bytes <= 0L) return ""
        val mb = bytes / 1048576.0
        return if (mb >= 1024.0) {
            String.format(Locale.US, "%.2f Go", mb / 1024.0)
        } else {
            String.format(Locale.US, "%.0f Mo", mb)
        }
    }
}
