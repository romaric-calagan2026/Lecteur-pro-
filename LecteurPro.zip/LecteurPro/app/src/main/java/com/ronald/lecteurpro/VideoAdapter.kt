package com.ronald.lecteurpro

import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

class VideoAdapter(
    private val context: Context,
    private val onClick: (Int) -> Unit
) : RecyclerView.Adapter<VideoAdapter.VH>() {

    var items: List<Video> = emptyList()
    var grid: Boolean = false

    private val cache = LruCache<Long, Bitmap>(80)
    private val pool = Executors.newFixedThreadPool(2)
    private val main = Handler(Looper.getMainLooper())

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val thumb: ImageView = v.findViewById(R.id.thumb)
        val duration: TextView = v.findViewById(R.id.duration)
        val title: TextView = v.findViewById(R.id.title)
        val info: TextView = v.findViewById(R.id.info)
    }

    override fun getItemViewType(position: Int): Int = if (grid) 1 else 0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val layout = if (viewType == 1) R.layout.item_video_grid else R.layout.item_video_list
        return VH(LayoutInflater.from(context).inflate(layout, parent, false))
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val v = items[position]
        h.title.text = v.title
        h.duration.text = Fmt.duration(v.durationMs)
        h.info.text = listOf(Fmt.size(v.size), v.folder)
            .filter { it.isNotBlank() }
            .joinToString("  •  ")
        h.thumb.tag = v.id

        val cached = cache.get(v.id)
        if (cached != null) {
            h.thumb.scaleType = ImageView.ScaleType.CENTER_CROP
            h.thumb.setImageBitmap(cached)
        } else {
            h.thumb.scaleType = ImageView.ScaleType.CENTER
            h.thumb.setImageResource(R.drawable.ic_play)
            pool.execute {
                val bmp = loadThumb(v)
                if (bmp != null) {
                    cache.put(v.id, bmp)
                    main.post {
                        if (h.thumb.tag == v.id) {
                            h.thumb.scaleType = ImageView.ScaleType.CENTER_CROP
                            h.thumb.setImageBitmap(bmp)
                        }
                    }
                }
            }
        }

        h.itemView.setOnClickListener {
            val p = h.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onClick(p)
        }
    }

    private fun loadThumb(v: Video): Bitmap? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                context.contentResolver.loadThumbnail(v.uri, Size(360, 202), null)
            } else {
                @Suppress("DEPRECATION")
                MediaStore.Video.Thumbnails.getThumbnail(
                    context.contentResolver, v.id, MediaStore.Video.Thumbnails.MINI_KIND, null
                )
            }
        } catch (_: Throwable) {
            null
        }
    }
}
